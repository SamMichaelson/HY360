package Graphics;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.Component;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Calendar;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import javax.swing.border.LineBorder;

import initialTables.initialTables;

import javax.swing.DefaultComboBoxModel;

public class Avarage_salary extends JFrame {

	private JPanel contentPane;
	
	int misthosStart=0;
	int misthosEnd=0;
	int misthosStart1[]=new int[50];
	int misthosEnd1[]=new int[50];
	
	
	int alloS=0;
	int alloE=0;
	int alloS1[]=new int[50];
	int alloE1[]=new int[50];
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	
	
	//sunartisi gia grafika tou avarage salary
	public Avarage_salary() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 157);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 235));
		contentPane.setFont(new Font("Arial", Font.BOLD, 22));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFrom = new JLabel("\u0391\u03A0\u039F:");
		lblFrom.setFont(new Font("Arial", Font.BOLD, 26));
		lblFrom.setBounds(0, 0, 83, 46);
		contentPane.add(lblFrom);
		
		JLabel lblTo = new JLabel("\u039C\u0395\u03A7\u03A1\u0399:");
		lblTo.setFont(new Font("Arial", Font.BOLD, 26));
		lblTo.setBounds(0, 48, 94, 46);
		contentPane.add(lblTo);
		
		JButton btnNewButton = new JButton("\u0394\u0395\u0399\u039E\u0395");
	//	btnNewButton.setIcon(new ImageIcon(Avarage_salary.class.getResource("/com/sun/javafx/scene/control/skin/caspian/fxvk-capslock-button.png")));
		btnNewButton.setBorder(new LineBorder(new Color(0, 0, 0), 0, true));
		btnNewButton.setBackground(new Color(255, 255, 0));
		btnNewButton.setAlignmentY(0.0f);
		btnNewButton.setBounds(291, 10, 245, 94);
		contentPane.add(btnNewButton);
	
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"2026", "2025", "2024", "2023","2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990"}));
		comboBox_2.setBounds(77, 10, 90, 34);
		contentPane.add(comboBox_2);
		
		JLabel lblNewLabel = new JLabel("\\");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 29));
		lblNewLabel.setBounds(167, 7, 18, 48);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBox_2_1 = new JComboBox();
		comboBox_2_1.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		comboBox_2_1.setBounds(197, 58, 41, 34);
		contentPane.add(comboBox_2_1);
		
		
		
		JComboBox comboBox_2_2 = new JComboBox();
		comboBox_2_2.setModel(new DefaultComboBoxModel(new String[] {"2026", "2025", "2024", "2023","2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990"}));
		comboBox_2_2.setBounds(95, 58, 90, 34);
		contentPane.add(comboBox_2_2);
		
		JLabel lblNewLabel_1 = new JLabel("\\");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 29));
		lblNewLabel_1.setBounds(184, 55, 18, 48);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBox_2_1_1 = new JComboBox();
		comboBox_2_1_1.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		comboBox_2_1_1.setBounds(179, 10, 41, 34);
		contentPane.add(comboBox_2_1_1);
		
		
		String yearStart1=comboBox_2.getSelectedItem().toString();
		String monthStart1=comboBox_2_1.getSelectedItem().toString();
		String yearEnd1=comboBox_2_2.getSelectedItem().toString();
		String monthEnd1=comboBox_2_1_1.getSelectedItem().toString();
		int yearStart = Integer.parseInt(yearStart1);
		int monthStart = Integer.parseInt(monthStart1);
		
		int yearEnd = Integer.parseInt(yearEnd1);
		int monthEnd = Integer.parseInt(monthEnd1);
		
		int days=30;
		
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f;  
				    f=new JFrame();  
				    String yearStart1=comboBox_2.getSelectedItem().toString();
					String monthStart1=comboBox_2_1.getSelectedItem().toString();
					String yearEnd1=comboBox_2_2.getSelectedItem().toString();
					String monthEnd1= comboBox_2_1_1.getSelectedItem().toString();
					int yearStart = Integer.parseInt(yearStart1);
					int monthStart = Integer.parseInt(monthStart1);
					
					int yearEnd = Integer.parseInt(yearEnd1);
					int monthEnd = Integer.parseInt(monthEnd1);
					int days=30;

					try {
						
						paymentDate(yearStart, monthStart,yearEnd,monthEnd, days);
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					double auxisiM= ((misthosEnd - misthosStart) / (double)(misthosStart * 100))*10000;
					double auxisiE= ((alloE - alloS) / (double)(alloS * 100))*10000;


				    JOptionPane.showMessageDialog(f,"pososto auxisis mistou : "+auxisiM+"%\n"+"pososto auxisis epidomaton : "+auxisiE+"%","mesos oros auxisis",JOptionPane.INFORMATION_MESSAGE);  
			}
		});
		
		
		
	}
	
	//sunartisi upologisomoy misthou kai epidomatwn
	public  String[] paymentDate(int yearS,int monthS,int yearE,int monthE, int day)throws SQLException, ClassNotFoundException {
		Connection con= initialTables.getConnection();
		Statement stmt = con.createStatement();
      ResultSet rs;
      rs=stmt.executeQuery("SELECT kidsAge,kids,married,employType,date,stuffType,stuff_id FROM stuff WHERE stuffType='monimos'" );

      String[][] pluss = new String[100][50];
      
      StringBuffer results = new StringBuffer();

      int k=0;
      int kids[]=new int[100];
      boolean marr[]=new boolean[100];
      boolean type[]=new boolean[50];
      LocalDate currentDate[]=new LocalDate[100];
      int day1[]=new int[100];
      int month1[]=new int[100];
      int year1[]=new int[100];
      String age1[]=new String[100];
      String type1[]=new String[100];
      String id[]=new String[100];

      
      while (rs.next()) {  
       
      	for (int i=1;i<8;i++) {
      	    
      			 pluss[k][i] = rs.getString(i);
      			 if(i==1) {
      				 age1[k]=pluss[k][1];
      			 }
      			 else if(i==2) {
       	        kids[k] = Integer.parseInt(pluss[k][2]);
      		   } else if(i==3) {
      			   if(pluss[k][3].equals("yes")) {
      				  marr[k]=true; 
      			   }else if( pluss[k][3].equals("no")) {
      				   marr[k]=false; }
           	   }else if(i==4) {
           		 if(pluss[k][4].equals("dioikitikos")) {
     				  type[k]=true; 
     			   }
     			   else if(pluss[k][4].equals("didaktikos")) {
     				   type[k]=false; }
           		 
           	   }else if(i==5) {
           		
                  if(pluss[k][5].length()>4) {
                  	  currentDate[k] = LocalDate.parse(pluss[k][5]);

                       day1[k]=currentDate[k].getDayOfMonth();
                       month1[k]=currentDate[k].getMonthValue();
                       year1[k]=currentDate[k].getYear();
                       
                  }
           	   }else if(i==6) {
           		   type1[k]=pluss[k][6];
           	   }else if(i==7) {
           		   id[k]=pluss[k][7];
           	   }
      	        

      	}   
      	
      	
      	
      	misthosStart1[k]=paymentSearch(age1[k], kids[k], marr[k], type[k], yearS,monthS, day,k);
      	
      	
      	misthosEnd1[k]=paymentSearch(age1[k], kids[k], marr[k], type[k], yearE,monthE, day,k);
      	alloS1[k]=allowance(age1[k], kids[k], marr[k], type[k], yearS,monthS, day,k);
      	alloE1[k]= allowance(age1[k], kids[k], marr[k], type[k], yearE,monthE, day,k);
                     	
     

        
       k++;
       int i=1;
                                        // Print the column value
      }
      for(int p=0;p<k;p++) {
        	misthosStart=misthosStart+misthosStart1[p];
        	misthosEnd=misthosEnd+misthosEnd1[p];
        	
        	alloS=alloS+alloS1[p];
        	alloE=alloE+alloE1[p];
        	
      }
      alloS=alloS/k;
      alloE=alloE/k;
     
      
      misthosStart=misthosStart/k;
      misthosEnd=misthosEnd/k;
      
      
      
      
      
      stmt.close();
      con.close();
      
      return id;
		
	
	}
	
	//sunartisi pou epistrefei to meso oro twn misthwn
	public int paymentSearch(String ages,int kids,boolean mar,boolean didaktikos,int yearS,int monthS,int days ,int p)throws SQLException, ClassNotFoundException {
		Connection con= initialTables.getConnection();
		int[] idd=new int[50];
		idd=takis();

		Statement stmt = con.createStatement();
        ResultSet rs;
        rs=stmt.executeQuery("SELECT stuff_id ,date FROM stuff WHERE stuffType='monimos'" );

      String[][] ss = new String[50][50];
      
      StringBuffer results = new StringBuffer();
      int ii=0;
      int ll=0;
      LocalDate currentDate1[]=new LocalDate[100];
      int day11[]=new int[100];
      int month11[]=new int[100];
      int year11[]=new int[100];
      while (rs.next()) {  
       
      	for ( ii=1;ii<3;ii++) {
      	
      			 ss[ll][ii] = rs.getString(ii);
      			 if(ii==2) {


      				 
      			  currentDate1[ll] = LocalDate.parse(ss[ll][2]);

                  day11[ll]=currentDate1[ll].getDayOfMonth();
                  month11[ll]=currentDate1[ll].getMonthValue();
                  year11[ll]=currentDate1[ll].getYear();

      			 }
      			 
      	}

       ll++;
       int i=1;
                                        // Print the column value
      }
      
                int misthos[]=new int[100];
      

		      	misthos[p]=1800;

		     	int startYear = year11[p];
	            int startMonth = month11[p]; // January
	            int startDay = day11[p];
                int endYear = yearS;
                int endMonth = monthS; // January
                int endDay= days;
                
                Calendar start = Calendar.getInstance();
                start.set(startYear, startMonth, startDay);
                Calendar end = Calendar.getInstance();
                end.set(endYear, endMonth, endDay);
                
                int yearsPassed = end.get(Calendar.YEAR) - start.get(Calendar.YEAR);
                if (end.get(Calendar.MONTH) < start.get(Calendar.MONTH)) {
                    yearsPassed--;
                } else if (end.get(Calendar.MONTH) == start.get(Calendar.MONTH)
                           && end.get(Calendar.DAY_OF_MONTH) < start.get(Calendar.DAY_OF_MONTH)) {
                    yearsPassed--;
                }
                System.out.println("Years passed between two dates: " + yearsPassed);
            
        

   
   //   double started=((years-2000)*365.24) + (months*30) + days;//2023-1-1
    	  System.out.println("started date   "+year11[p]+"-"+month11[p]+"-"+day11[p]); 


		//System.out.println(today+" "+started+" "+deference +" deference");
		if(yearsPassed>=1) {
  		misthos[p]+=misthos[p]*0.15*yearsPassed;
		}
		System.out.println("ffinal payment is: "+misthos);
      double allawance[]=new double[50];
      

      String[] tokens = ages.split(",");

      int[] numbers = new int[50];
     	

      int k=0;
      if(mar)k++;
      if(kids==0) {

      	allawance[p]=0;
      }else {

    	  for (int l = 0; l < tokens.length; l++) {

              numbers[ii] = Integer.parseInt(tokens[l]);
              if(numbers[ii]<18) {
            	  k++;
              }
          }
      
      }

      allawance[p]=(int) Math.round(k*0.05*misthos[p]);
      if(didaktikos)allawance[p]+=50;//epidoma viv + erevnas
      System.out.println(allawance);
      			int sum=0;
    	     
    	    	   
    	    	sum=misthos[p];
    	    	
    	       
     
      	
      stmt.close();
      con.close();
      

      
	  return sum;
	
	}
	public int[] takis() throws ClassNotFoundException, SQLException {
		Connection con= initialTables.getConnection();

		Statement stmt = con.createStatement();
	    String monimos;
	   
       ResultSet rs;
       ResultSet rs1;
    
     
       stmt = con.createStatement();     // Create a Statement object      
    
       	 rs = stmt.executeQuery("SELECT stuff_id FROM stuff WHERE stuffType='monimos'  ");  
       	 int foo[]=new int[50];
      
       int i=0;
       int[] theNumbers = new int[50];
       while (rs.next()) {               // Position the cursor                 3 
       monimos = rs.getString(1);             // Retrieve only the first column value
        foo[i] = Integer.parseInt(monimos);
        
        theNumbers[i]=foo[i];
        
        
        		i++;
        		
        		
       }
       
      
       
       rs.close(); 
       return foo ;
		
		
	}
	
	//sunartisi pou epistrefei to meso oro epidwmaton
	public int allowance(String ages,int kids,boolean mar,boolean didaktikos,int yearS,int monthS,int days ,int p)throws SQLException, ClassNotFoundException {
		Connection con= initialTables.getConnection();
		int[] idd=new int[50];
		idd=takis();

		Statement stmt = con.createStatement();
        ResultSet rs;
        rs=stmt.executeQuery("SELECT stuff_id ,date FROM stuff " );

      String[][] ss = new String[50][50];
      
      StringBuffer results = new StringBuffer();
      int ii=0;
      int ll=0;
      LocalDate currentDate1[]=new LocalDate[100];
      int day11[]=new int[100];
      int month11[]=new int[100];
      int year11[]=new int[100];
      while (rs.next()) {  
       
      	for ( ii=1;ii<3;ii++) {
      	
      			 ss[ll][ii] = rs.getString(ii);
      			 
      			 if(ii==2) {
      			  currentDate1[ll] = LocalDate.parse(ss[ll][2]);

                  day11[ll]=currentDate1[ll].getDayOfMonth();
                  month11[ll]=currentDate1[ll].getMonthValue();
                  year11[ll]=currentDate1[ll].getYear();

      			 }
      			 
      	}

       ll++;
       int i=1;
      }
      
                int misthos[]=new int[100];
      

		      	misthos[p]=1800;

		     	int startYear = year11[p];
	            int startMonth = month11[p]; // January
	            int startDay = day11[p];
                int endYear = yearS;
                int endMonth = monthS; // January
                int endDay= days;
                
                Calendar start = Calendar.getInstance();
                start.set(startYear, startMonth, startDay);
                Calendar end = Calendar.getInstance();
                end.set(endYear, endMonth, endDay);
                
                int yearsPassed = end.get(Calendar.YEAR) - start.get(Calendar.YEAR);
                if (end.get(Calendar.MONTH) < start.get(Calendar.MONTH)) {
                    yearsPassed--;
                } else if (end.get(Calendar.MONTH) == start.get(Calendar.MONTH)
                           && end.get(Calendar.DAY_OF_MONTH) < start.get(Calendar.DAY_OF_MONTH)) {
                    yearsPassed--;
                }
                System.out.println("Years passed between two dates: " + yearsPassed);
            
        


		if(yearsPassed>=1) {
  		misthos[p]+=misthos[p]*0.15*yearsPassed;
		}
		System.out.println("ffinal payment is: "+misthos);
      double allawance[]=new double[50];
      

      String[] tokens = ages.split(",");

      int[] numbers = new int[50];
     	

      int k=0;
      if(mar)k++;
      if(kids==0) {

      	allawance[p]=0;
      }else {

    	  for (int l = 0; l < tokens.length; l++) {

              numbers[ii] = Integer.parseInt(tokens[l]);
              if(numbers[ii]<18) {
            	  k++;
              }
          }
      
      }

      allawance[p]=(int) Math.round(k*0.05*misthos[p]);
      if(didaktikos)allawance[p]+=50;//epidoma viv + erevnas
      System.out.println(allawance[p]);
      	
    	       
     
      	
      stmt.close();
      con.close();
      
     int allo=(int) Math.round(allawance[p]);  ;

      
	  return allo;
	
	}
	
	
	
	
	
}
