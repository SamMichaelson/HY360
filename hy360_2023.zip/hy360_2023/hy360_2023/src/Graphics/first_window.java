package Graphics;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JToolBar;
import javax.swing.JSpinner;
import javax.swing.JList;
import javax.imageio.ImageIO;
import javax.swing.AbstractListModel;
import javax.swing.JScrollBar;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.ListSelectionModel;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;

import Graphics.recruitment;
import initialTables.initialTables;

import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;
import java.awt.SystemColor;
import javax.swing.border.LineBorder;


public class first_window extends initialTables{

	private JFrame frame;

	private  Connection con;
	
	String [] array=new String[3];
	String katast=new String();
	String synolMistou=new String();
	String newDate=new String();
	recruitment obj;
    int ole=0;
    String[] id1=new String[50];
	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
    
  //grafika gia to first window

	public first_window() throws ClassNotFoundException, SQLException {
		this.con=con; 
		initialize();
		
	//	recruitment frame = new recruitment(this);
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	
	private void initialize() throws ClassNotFoundException, SQLException {
		frame = new JFrame();
		frame.getContentPane().setForeground(new Color(224, 255, 255));
		 
	//	JLabel background=new JLabel(new ImageIcon(this.getClass().getResource("/personal.png")));
		//frame.add(background);
		frame.setContentPane(new JLabel(new ImageIcon(this.getClass().getResource("/backround.jpeg"))));
		frame.getContentPane().setLayout(new FlowLayout()); 
		frame.setResizable(false);
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 16));
		frame.getContentPane().setBackground(Color.GRAY);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		JButton btnNewButton = new JButton("Προσληψη Μονιμου");
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 16));
		btnNewButton.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnNewButton.setBackground(SystemColor.textHighlight);
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			 obj=new recruitment(first_window.this);
			 
			 obj.setVisible(true);
			}
		});
		btnNewButton.setBounds(39, 159, 257, 70);
		frame.getContentPane().add(btnNewButton);
		
		
		
		JButton btnNeaSymbash = new JButton("Προσληψη Συμβασιουχου");
		btnNeaSymbash.setBorder(new LineBorder(new Color(255, 255, 0), 3, true));
		btnNeaSymbash.setBackground(SystemColor.textHighlight);
		btnNeaSymbash.setFont(new Font("Arial Black", Font.BOLD, 16));
		btnNeaSymbash.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				symbash obj2=new symbash();
				obj2.setVisible(true);
			}
		});
		btnNeaSymbash.setBounds(39, 257, 257, 70);
		frame.getContentPane().add(btnNeaSymbash);
		
		JButton btnAllaghStoixeion = new JButton("\u0391\u03BB\u03BB\u03B1\u03B3\u03B7 \u03A3\u03C4\u03BF\u03B9\u03C7\u03B5\u03B9\u03C9\u03BD \u03A0\u03C1\u03BF\u03C3\u03C9\u03C0\u03B9\u03BA\u03BF\u03C5");
		btnAllaghStoixeion.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnAllaghStoixeion.setBackground(SystemColor.textHighlight);
		btnAllaghStoixeion.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAllaghStoixeion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Change_data obj6=new Change_data();
				obj6.setVisible(true);
			}
		});
		btnAllaghStoixeion.setBounds(39, 449, 214, 57);
		frame.getContentPane().add(btnAllaghStoixeion);
		
		JButton btnMetabolhMisuodosias = new JButton("\u039C\u03B5\u03C4\u03B1\u03B2\u03BF\u03BB\u03B7 \u039C\u03B9\u03C3\u03B8\u03BF\u03B4\u03BF\u03C3\u03B9\u03B1\u03C2");
		btnMetabolhMisuodosias.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnMetabolhMisuodosias.setBackground(SystemColor.textHighlight);
		btnMetabolhMisuodosias.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnMetabolhMisuodosias.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Change_salary obj5=new Change_salary();
				obj5.setVisible(true);
			}
		});
		btnMetabolhMisuodosias.setBounds(39, 540, 214, 57);
		frame.getContentPane().add(btnMetabolhMisuodosias);
		
		JButton btnApolyshsyntaksh = new JButton("\u0391\u03C0\u03BF\u03BB\u03C5\u03C3\u03B7/\u03A3\u03C5\u03BD\u03C4\u03B1\u03BE\u03B7");
		btnApolyshsyntaksh.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnApolyshsyntaksh.setBackground(SystemColor.textHighlight);
		btnApolyshsyntaksh.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnApolyshsyntaksh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fire_person obj5=new Fire_person();
				obj5.setVisible(true);
			}
		});
		btnApolyshsyntaksh.setBounds(39, 640, 214, 57);
		frame.getContentPane().add(btnApolyshsyntaksh);
		
		JButton btnNewButton_1 = new JButton("\u039A\u03B1\u03C4\u03B1\u03C3\u03C4\u03B1\u03C3\u03B7 \u039C\u03B9\u03C3\u03B8\u03BF\u03B4\u03BF\u03C3\u03B9\u03B1\u03C2");
		btnNewButton_1.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnNewButton_1.setBackground(SystemColor.textHighlight);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.setBounds(632, 172, 466, 57);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_1_2 = new JButton("\u03A3\u03C5\u03BD\u03BF\u03BB\u03B9\u03BA\u03BF \u03A5\u03C8\u03BF\u03C2 \u039C\u03B9\u03C3\u03B8\u03BF\u03C5");
		btnNewButton_1_2.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnNewButton_1_2.setBackground(SystemColor.textHighlight);
		btnNewButton_1_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1_2.setBounds(632, 330, 466, 57);
		frame.getContentPane().add(btnNewButton_1_2);
		
		JButton btnNewButton_1_1 = new JButton("\u039C\u03B5\u03B3\u03B9\u03C3\u03C4\u03BF\u03C2 \u039C\u03B9\u03C3\u03B8\u03BF\u03C2");
		btnNewButton_1_1.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnNewButton_1_1.setBackground(SystemColor.textHighlight);
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1_1.setBounds(632, 242, 142, 57);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("\u039C\u03B5\u03C3\u03BF\u03C2 \u039C\u03B9\u03C3\u03B8\u03BF\u03C2");
		btnNewButton_1_1_1.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnNewButton_1_1_1.setBackground(SystemColor.textHighlight);
		btnNewButton_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1_1_1.setBounds(794, 242, 142, 57);
		frame.getContentPane().add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_1_2 = new JButton("\u0395\u03BB\u03B1\u03C7\u03B9\u03C3\u03C4\u03BF\u03C2 \u039C\u03B9\u03C3\u03B8\u03BF\u03C2");
		btnNewButton_1_1_2.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnNewButton_1_1_2.setBackground(SystemColor.textHighlight);
		btnNewButton_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1_1_2.setBounds(957, 242, 142, 57);
		frame.getContentPane().add(btnNewButton_1_1_2);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Arial", Font.BOLD, 15));
		comboBox.setBackground(Color.LIGHT_GRAY);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"m.dioikitiko", "m.didaktiko","s.dioikitiko", "s.didaktiko"}));
		comboBox.setBounds(752, 72, 177, 38);
		frame.getContentPane().add(comboBox);
		
		
		
		
		
		
		
		JButton btnNewButton_2 = new JButton("\u03A3\u03C4\u03BF\u03B9\u03C7\u03B5\u03B9\u03B1 \u03A5\u03C0\u03B1\u03BB\u03BB\u03B7\u03BB\u03BF\u03C5");
		btnNewButton_2.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnNewButton_2.setBackground(SystemColor.textHighlight);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Persons_Data obj4=new Persons_Data();
				obj4.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(645, 628, 452, 70);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("\u039C\u03B5\u03C3\u03B7 \u0391\u03C5\u03BE\u03B7\u03C3\u03B7 \u039C\u03B9\u03C3\u03B8\u03C9\u03BD \u03BA \u0395\u03C0\u03B9\u03B4\u03C9\u03BC\u03B1\u03C4\u03C9\u03BD");
		btnNewButton_2_1.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnNewButton_2_1.setBackground(SystemColor.textHighlight);
		btnNewButton_2_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Avarage_salary obj3=new Avarage_salary();
				obj3.setVisible(true);
				
			}
		});
		btnNewButton_2_1.setBounds(645, 529, 452, 70);
		frame.getContentPane().add(btnNewButton_2_1);
		frame.setBounds(100, 100, 1144, 769);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		JButton btnNewButton_1_2_1 = new JButton("\u039A\u03B1\u03C4\u03B1\u03B2\u03BF\u03BB\u03B7 \u03BC\u03B9\u03C3\u03B8\u03BF\u03B4\u03BF\u03C3\u03B9\u03B1\u03C2!!!");
		btnNewButton_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f;  
			    f=new JFrame();  
			    try {
			    	
			    	ole++;
                 newDate=paymentRefresh();
                 paymentRefresh1();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    
			    JOptionPane.showMessageDialog(f,"Success","Katavoli Misthothosias",JOptionPane.INFORMATION_MESSAGE);  
		
				
			}
		});
		
		
		btnNewButton_1_2_1.setForeground(Color.RED);
		btnNewButton_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1_2_1.setBorder(new LineBorder(new Color(255, 255, 0), 2, true));
		btnNewButton_1_2_1.setBackground(SystemColor.textHighlight);
		btnNewButton_1_2_1.setBounds(632, 422, 466, 57);
		frame.getContentPane().add(btnNewButton_1_2_1);
		
		
		JLabel lblFoto = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/UoC_logo.png")).getImage();
		lblFoto.setIcon(new ImageIcon(img));
		lblFoto.setBounds(39, 4, 124, 124);
		frame.getContentPane().add(lblFoto);
		
		JLabel lblFoto2 = new JLabel("");
		Image img2 = new ImageIcon(this.getClass().getResource("/settings.png")).getImage();
		lblFoto2.setIcon(new ImageIcon(img2));
		lblFoto2.setBounds(39, 340, 90, 90);
		frame.getContentPane().add(lblFoto2);
		
		JLabel lblFoto3 = new JLabel("");
		Image img3 = new ImageIcon(this.getClass().getResource("/personal.png")).getImage();
		lblFoto3.setIcon(new ImageIcon(img3));
		lblFoto3.setBounds(645, 41, 95, 95);
		frame.getContentPane().add(lblFoto3);
		
		String depa= department1(comboBox);
		 array=minMaxAvg("m.dioikitiko" );
		 array[0]=minMaxAvg("m.dioikitiko" )[0];
		 array[1]=minMaxAvg("m.dioikitiko" )[1];
		 array[2]=minMaxAvg("m.dioikitiko" )[2];
		 katast=katastasi("m.dioikitiko");
		 synolMistou=sunolikosYpsosMisthou("m.dioikitiko");
		 comboBox.addItemListener(new ItemListener() {
           public void itemStateChanged(ItemEvent event) {
               if (event.getStateChange() == ItemEvent.SELECTED) {
                   String selected = (String) event.getItem();
                   try {
					 array=minMaxAvg(selected );
					 array[0]=minMaxAvg(selected )[0];
					 array[1]=minMaxAvg(selected )[1];
					 array[2]=minMaxAvg(selected )[2]; 
					 katast=katastasi(selected);
					 synolMistou=sunolikosYpsosMisthou(selected);
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                   
               }
           }
       });
		
		
	   
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f;  
				    f=new JFrame();  
				    JOptionPane.showMessageDialog(f,katast,"katastash misuodosias",JOptionPane.INFORMATION_MESSAGE);  
			}
		});
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.setBounds(645, 628, 452, 70);
		frame.getContentPane().add(btnNewButton_2);
		
		btnNewButton_2_1.setBounds(645, 529, 452, 70);
		frame.getContentPane().add(btnNewButton_2_1);
		frame.setBounds(100, 100, 1164, 780);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f;  
				    f=new JFrame();  
				    JOptionPane.showMessageDialog(f,synolMistou,"Synoliko ipsos misuoy",JOptionPane.INFORMATION_MESSAGE);  
			}
		});
		
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f;  
				    f=new JFrame();  
				    JOptionPane.showMessageDialog(f,String.valueOf(array[0]),"Max Salary",JOptionPane.INFORMATION_MESSAGE);  
			}
		});
		
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f;  
				    f=new JFrame();  
				    JOptionPane.showMessageDialog(f,String.valueOf(array[2]),"Avarage Salary",JOptionPane.INFORMATION_MESSAGE);  
			}
		});
		
		
		btnNewButton_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f;  
				    f=new JFrame();  
				    JOptionPane.showMessageDialog(f,String.valueOf(array[1]),"Min Salary",JOptionPane.INFORMATION_MESSAGE);  
			}
		});
	}
	public String department1(JComboBox comboBox) {
		
		String department=comboBox.getSelectedItem().toString();
		return department;
	}
	
	//sunartisi upologismou gia min max avg pou epistrefei pinaka me 3 stoixei pou einai auta
	public String[] minMaxAvg(String s) throws ClassNotFoundException, SQLException {
		this.con = getConnection();
	    String monimos;
	   
       ResultSet rs;
       ResultSet rs1;
     
       Statement stmt;
     
       stmt = con.createStatement();     // Create a Statement object      
       if(s=="m.dioikitiko") {
       	 rs = stmt.executeQuery("SELECT P.salary FROM payroll P,stuff F where F.stuffType='monimos' and F.employType='dioikitikos' and F.stuff_id=P.stuff_id  ");  
       }																											
       else if(s=="m.didaktiko") {
       	rs = stmt.executeQuery("SELECT P.salary FROM payroll P,stuff F where F.stuffType='monimos' and F.employType='didaktikos' and F.stuff_id=P.stuff_id  "); 
       }
       else if(s=="s.dioikitiko") {
       	rs = stmt.executeQuery("SELECT P.salary FROM payroll P,stuff F where F.stuffType='symvasiouxos' and F.employType='dioikitikos' and F.stuff_id=P.stuff_id  "); 
       }
       else  {
       	rs = stmt.executeQuery("SELECT P.salary FROM payroll P,stuff F where F.stuffType='symvasiouxos' and F.employType='didaktikos' and F.stuff_id=P.stuff_id  "); 
       }
      
       int i=0;
       int[] theNumbers = new int[50];
       while (rs.next()) {               // Position the cursor                 3 
       monimos = rs.getString(1);             // Retrieve only the first column value
       int foo = Integer.parseInt(monimos);
        
        theNumbers[i]=foo;
        		i++;
                                         // Print the column value
       }
       String [] arr=new String[3];
       int sum=0;
       int min=theNumbers[0];
       int max=theNumbers[0];
       
       for (int k=0;k<i;k++) {
       	sum=sum+theNumbers[k];
       	if(theNumbers[k]<min){
               min=theNumbers[k];
               
             }else if(theNumbers[k]>max) {
           	  max=theNumbers[k];
           	  
             }
       }
       int mesos_oros=(sum/i);
       String smax=Integer.toString(max);
       String smin=Integer.toString(min);
       String avg=Integer.toString(mesos_oros);
      
       arr[0]=smax;
       arr[1]=smin;
       arr[2]=avg;
       
       
       
       System.out.println(mesos_oros);
       
       rs.close(); 
       return arr;
		
		
	}
	
	//sunartsi katastasis kathe atomou analoga me ti katigoria pou vriskete
	public String  katastasi(String s) throws ClassNotFoundException, SQLException {
		this.con = getConnection();
	    String monimos;
	   
       ResultSet rs;
       ResultSet rs1;
     
       Statement stmt;
     
       stmt = con.createStatement();     // Create a Statement object      
       if(s=="m.dioikitiko") {
       	 rs = stmt.executeQuery("SELECT F.name ,F.bankName, D.payDate, D.payCheck FROM payroll_data D,stuff F where F.stuffType='monimos' and F.employType='dioikitikos' and F.stuff_id=D.stuff_id ");  
      
       
       }
       else if(s=="m.didaktiko") {
      	 rs = stmt.executeQuery("SELECT F.name ,F.bankName, D.payDate, D.payCheck FROM payroll_data D,stuff F where F.stuffType='monimos' and F.employType='didaktikos' and F.stuff_id=D.stuff_id ");  
       }
       else if(s=="s.dioikitiko") {
      	 rs = stmt.executeQuery("SELECT F.name ,F.bankName, D.payDate, D.payCheck FROM payroll_data D,stuff F where F.stuffType='symvasiouxos' and F.employType='dioikitikos' and F.stuff_id=D.stuff_id ");  
       }
       else  {
      	 rs = stmt.executeQuery("SELECT F.name ,F.bankName, D.payDate, D.payCheck FROM payroll_data D,stuff F where F.stuffType='symvasiouxos' and F.employType='didaktikos' and F.stuff_id=D.stuff_id ");  
       }
      
       
       String[] pluss = new String[50];
       StringBuffer results = new StringBuffer();
       String separator = ", ";
       String separator1 = "\n";
       int k=1;
       while (rs.next()) {  
       	 results.append(k).append(". ");// Position the cursor        
       	for (int i=1;i<5;i++) {
           pluss[i] = rs.getString(i);
          
           results.append(pluss[i]).append(separator);

       	}
       	  results.append(separator1);
       	  
        k++;
        int i=1;
                                         // Print the column value
       }
       System.out.println(results);
       
       rs.close(); 
       return results.toString();
		
		
	}
	
	
	//sunartisi pou upologizei kai epistrefei to sunoliko mistho analoga me ti katigoria
	
	public String  sunolikosYpsosMisthou(String s) throws ClassNotFoundException, SQLException {
		this.con = getConnection();
	    String monimos;
	   
       ResultSet rs;
       ResultSet rs1;
     
       Statement stmt;
     
       stmt = con.createStatement();     // Create a Statement object      
       if(s=="m.dioikitiko") {
       	 rs = stmt.executeQuery("SELECT  D.payCheck FROM payroll_data D,stuff F where F.stuffType='monimos' and F.employType='dioikitikos' and F.stuff_id=D.stuff_id ");  
      
       
       }
       else if(s=="m.didaktiko") {
      	 rs = stmt.executeQuery("SELECT  D.payCheck FROM payroll_data D,stuff F where F.stuffType='monimos' and F.employType='didaktikos' and F.stuff_id=D.stuff_id ");  
       }
       else if(s=="s.dioikitiko") {
      	 rs = stmt.executeQuery("SELECT  D.payCheck FROM payroll_data D,stuff F where F.stuffType='symvasiouxos' and F.employType='dioikitikos' and F.stuff_id=D.stuff_id ");  
       }
       else  {
      	 rs = stmt.executeQuery("SELECT  D.payCheck FROM payroll_data D,stuff F where F.stuffType='symvasiouxos' and F.employType='didaktikos' and F.stuff_id=D.stuff_id ");  
       }
      
       
       int i=0;
       int[] theNumbers = new int[100];
       while (rs.next()) {               // Position the cursor                 3 
       monimos = rs.getString(1);             // Retrieve only the first column value
       int foo = Integer.parseInt(monimos);
        
        theNumbers[i]=foo;
        		i++;
                                         // Print the column value
       }
       int sum=0;
       for (int k=0;k<i;k++) {
       	sum=sum+theNumbers[k];
       	
       }
     
       String synMisthou=Integer.toString(sum);
       System.out.println(synMisthou);
       
       rs.close(); 
       return synMisthou;
		
		
       
     
	}
	
	
	
	int month=01;
	int year=2023;
	
	//sunartisi pou upologizei kai kanei update to mistho tou monimou  analoga me ti xronologia 
	
	public  String paymentRefresh()throws SQLException, ClassNotFoundException {
		Connection con= initialTables.getConnection();
		Statement stmt = con.createStatement();
      ResultSet rs;
      rs=stmt.executeQuery("SELECT stuff_id,salary,allowance FROM payroll " );

      String[][] pluss = new String[50][50];
      
      StringBuffer results = new StringBuffer();

      int k=0;
      while (rs.next()) {  
       
      	for (int i=1;i<4;i++) {
      	
      			 pluss[k][i] = rs.getString(i);
      		   
          
      	}

       k++;
       int i=1;
                                        // Print the column value
      }
      String paydate;
      if(month==13) {
    	    year++;
    	    month=1;
    	  paydate=year+"-"+month+"-30";

      }else {
  	    paydate=year+"-"+month+"-30";

      }
     
     
     SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); // your template here
     java.util.Date dateStr;
     java.sql.Date dateDB = null;
	try {
		dateStr = formatter.parse(paydate);
	    dateDB = new java.sql.Date(dateStr.getTime());
	    int paycheck[]=new int[50];
	     
	     for(int p=0; p<k;p++)
	     {
	          paycheck[p]= Integer.parseInt(pluss[p][2])+ Integer.parseInt(pluss[p][3]);

	          String JSON = "INSERT IGNORE INTO payroll_data(stuff_id,payDate, payCheck)"
	            		+ " VALUES ('"+pluss[p][1]+"', '"+dateDB+"', '"+paycheck[p]+"')";
	            	stmt.executeUpdate(JSON);
	           JSON = "UPDATE payroll_data SET payDate='"+dateDB+"', payCheck='"+paycheck[p]+"' WHERE stuff_id='"+pluss[p][1]+"'";
	            	stmt.executeUpdate(JSON);	
	            	
	   		
	           
	     }

	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  
     month++;

    
      	
      stmt.close();
      con.close();
      
      String date = dateDB.toString();
      paymentRefresh1();
      
      return date;
		
	
	}
	
	
	//sunartisi pou epistrefei ena string me ta stoixeia pou xreiazontai gia ton upologismo tou kainourgiou misthou
	
	public  String[] paymentRefresh1()throws SQLException, ClassNotFoundException {
		Connection con= initialTables.getConnection();
		Statement stmt = con.createStatement();
      ResultSet rs;
      rs=stmt.executeQuery("SELECT kidsAge,kids,married,employType,date,stuffType,stuff_id FROM stuff WHERE stuffType='monimos'" );

      String[][] pluss = new String[100][50];
      
      StringBuffer results = new StringBuffer();

      int k=0;
      int kids[]=new int[100];
      boolean marr[]=new boolean[100];
      boolean type[]=new boolean[50];
      LocalDate currentDate[]=new LocalDate[100];
      int day1[]=new int[100];
      int month1[]=new int[100];
      int year1[]=new int[100];
      String age1[]=new String[100];
      String type1[]=new String[100];
      String id[]=new String[100];

      
      while (rs.next()) {  
       
      	for (int i=1;i<8;i++) {
      	    
      			 pluss[k][i] = rs.getString(i);
      			 if(i==1) {
      				 age1[k]=pluss[k][1];
      			 }
      			 else if(i==2) {
       	        kids[k] = Integer.parseInt(pluss[k][2]);
      		   } else if(i==3) {
      			   if(pluss[k][3].equals("yes")) {
      				  marr[k]=true; 
      			   }else if( pluss[k][3].equals("no")) {
      				   marr[k]=false; }
           	   }else if(i==4) {
           		 if(pluss[k][4].equals("dioikitikos")) {
     				  type[k]=true; 
     			   }
     			   else if(pluss[k][4].equals("didaktikos")) {
     				   type[k]=false; }
           		 
           	   }else if(i==5) {
           		
                  if(pluss[k][5].length()>4) {
                  	  currentDate[k] = LocalDate.parse(pluss[k][5]);

                       day1[k]=currentDate[k].getDayOfMonth();
                       month1[k]=currentDate[k].getMonthValue();
                       year1[k]=currentDate[k].getYear();
                       
                  }
           	   }else if(i==6) {
           		   type1[k]=pluss[k][6];
           	   }else if(i==7) {
           		   id[k]=pluss[k][7];
           	   }
      	        

      	}
      	paymentRefreshRec(age1[k], kids[k], marr[k], type[k], year1[k],month1[k], day1[k],k);

      	

       k++;
       int i=1;
                                        // Print the column value
      }
      

     
      
      
      
      stmt.close();
      con.close();
      
      return id;
		
	
	}
	
	//sunartisi kai update misthou analoga me thn kainorgia imerominia
	
	public int[] paymentRefreshRec(String ages,int kids,boolean mar,boolean didaktikos,int years,int months,int days ,int p)throws SQLException, ClassNotFoundException {
		Connection con= initialTables.getConnection();
		int[] idd=new int[50];
		idd=takis();

		Statement stmt = con.createStatement();
        ResultSet rs;
        rs=stmt.executeQuery("SELECT stuff_id ,date FROM stuff WHERE stuffType='monimos'" );

      String[][] ss = new String[50][50];
      
      StringBuffer results = new StringBuffer();
      int ii=0;
      int ll=0;
      LocalDate currentDate1[]=new LocalDate[100];
      int day11[]=new int[100];
      int month11[]=new int[100];
      int year11[]=new int[100];
      while (rs.next()) {  
       
      	for ( ii=1;ii<3;ii++) {
      	
      			 ss[ll][ii] = rs.getString(ii);
      			 if(ii==2) {

      				 
      			  currentDate1[ll] = LocalDate.parse(ss[ll][2]);

                  day11[ll]=currentDate1[ll].getDayOfMonth();
                  month11[ll]=currentDate1[ll].getMonthValue();
                  year11[ll]=currentDate1[ll].getYear();

      			 }
      			 
      	}

       ll++;
       int i=1;
                                        // Print the column value
      }
      
      int misthos[]=new int[100];
      
      
      

  
			misthos[p]=1800;
		
     
        LocalDate currentDate;
        int day1=0;
        int month1=0;
        int year1=0;
        if(newDate.length()>4) {
        	  currentDate = LocalDate.parse(newDate);

             day1=currentDate.getDayOfMonth();
             month1=currentDate.getMonthValue();
             year1=currentDate.getYear();
             
        }
		
      
        
        
        
     
                int startYear = year11[p];
                int startMonth = month11[p]; // January
                int startDay = day11[p];
                int endYear = year1;
                int endMonth = month1; // January
                int endDay = day1;
                
                Calendar start = Calendar.getInstance();
                start.set(startYear, startMonth, startDay);
                Calendar end = Calendar.getInstance();
                end.set(endYear, endMonth, endDay);
                
                int yearsPassed = end.get(Calendar.YEAR) - start.get(Calendar.YEAR);
                if (end.get(Calendar.MONTH) < start.get(Calendar.MONTH)) {
                    yearsPassed--;
                } else if (end.get(Calendar.MONTH) == start.get(Calendar.MONTH)
                           && end.get(Calendar.DAY_OF_MONTH) < start.get(Calendar.DAY_OF_MONTH)) {
                    yearsPassed--;
                }
                System.out.println("Years passed between two dates: " + yearsPassed);
            
        

   


		if(yearsPassed>=1) {
  		misthos[p]+=misthos[p]*0.15*yearsPassed;
		}
		System.out.println("final payment is: "+misthos);
      double allawance[]=new double[50];
      

      String[] tokens = ages.split(",");

      int[] numbers = new int[50];
     	

      int k=0;
      if(mar)k++;
      if(kids==0) {

      	allawance[p]=0;
      }else {

    	  for (int l = 0; l < tokens.length; l++) {

              numbers[ii] = Integer.parseInt(tokens[l]);
              if(numbers[ii]<18) {
            	  k++;
              }
          }
      
      }

      allawance[p]=(int) Math.round(k*0.05*misthos[p]);
      if(didaktikos)allawance[p]+=50;//epidoma viv + erevnas
      System.out.println(allawance);


    	      	
    	     String JSON = "UPDATE payroll SET  salary='"+misthos[p]+"' WHERE stuff_id='"+idd[p]+"'";
    			
    	      stmt.executeUpdate(JSON);

    	 
      
     
      	
      stmt.close();
      con.close();
	  return misthos;
	
	}
	
	public int[] takis() throws ClassNotFoundException, SQLException {
		Connection con= initialTables.getConnection();

		Statement stmt = con.createStatement();
	    String monimos;
	   
       ResultSet rs;
       ResultSet rs1;
    
     
       stmt = con.createStatement();     // Create a Statement object      
    
       	 rs = stmt.executeQuery("SELECT stuff_id FROM stuff WHERE stuffType='monimos'  ");  
       	 int foo[]=new int[50];
      
       int i=0;
       int[] theNumbers = new int[50];
       while (rs.next()) {               // Position the cursor                 3 
       monimos = rs.getString(1);             // Retrieve only the first column value
        foo[i] = Integer.parseInt(monimos);
        
        theNumbers[i]=foo[i];
        
        
        		i++;
        		
        		
                                         // Print the column value
       }
       
      
       
       rs.close(); 
       return foo ;
		
		
	}
	
	

	
	
	
		
	}

